#' gatepoints.
#'
#' Allows user to gate a region on a plot and returns points within it.
#' @name gatepoints
#' @docType package
NULL
