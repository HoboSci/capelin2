library(testthat)
library(gatepoints)

test_check("gatepoints")
